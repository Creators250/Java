package chap09.others;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.*;

public class RePattern {

	public static void main(String[] args) {
		study008();
	}
	
	// Exercise
	public static void study008() {
		String input 	= "java=20;php=140;android=90";
		Pattern pattern		= Pattern.compile("(?<name>[A-z]+)=(?<time>\\d+);?");
		Matcher matcher		= pattern.matcher(input);
		Map<String, Integer> courseObj	= new HashMap<String, Integer>();
		
		while(matcher.find()){
			String name		= matcher.group("name");
			Integer time	= Integer.parseInt(matcher.group("time"));
			
			courseObj.put(name, time);
		}
		
		Iterator<String> itr		= courseObj.keySet().iterator();
		while(itr.hasNext()){
			String key		= itr.next();
			Integer value	= courseObj.get(key);
			System.out.println(key + " : " + value); 
		}
	}
	
	// Giới hạn sự tham ăn
	public static void study007() {
		String input = "Programming > Mobile > Android > Java";

		Pattern pattern = Pattern.compile("(?<fileName>.*?)>");
		Matcher matcher = pattern.matcher(input);

		while (matcher.find()) {
			System.out.println(matcher.group("fileName"));
		}
	}
		
	// Group name
	public static void study006() {
		String  input 	= "nhg-23212"; 
		Pattern pattern = Pattern.compile("[A-z]{3}-(?<id>\\d+)");	
		Matcher matcher = pattern.matcher(input);
		
		System.out.println(matcher.groupCount());
		while(matcher.find()){
			System.out.println(matcher.group(0));
			System.out.println(matcher.group(1));
			System.out.println(matcher.group("id"));
		}
	}
	
	// Group
	public static void study005() {
		String input = "Java-is---very-----easy";
		// Java-is---very-----easy
		// 01234567890123456789012
		
		Pattern pattern = Pattern.compile("-+");
		Matcher matcher = pattern.matcher(input);
		
		while(matcher.find()){
			System.out.printf("Start \t: %s \n", matcher.start());
			System.out.printf("End \t: %s \n", matcher.end());
			System.out.printf("Group \t: %s \n", matcher.group());
			System.out.println("-------------------");
		}
		
	}
	
	// lookingAt
	public static void study004() {
		String inputOne	= "javaandroid";	
		
		Pattern pattern = Pattern.compile("java", Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(inputOne);

		if (matcher.matches()) {
			System.out.println("Dữ liệu hợp lệ");
		} else {
			System.out.println("Dữ liệu không hợp lệ");
		}
		
		if (matcher.lookingAt()) {
			System.out.println("Dữ liệu hợp lệ");
		} else {
			System.out.println("Dữ liệu không hợp lệ");
		}
	}
		
	// matcher.replaceAll 
	public static void study003() {
		String inputOne = "Java is very  easy";

		Pattern pattern = Pattern.compile("\\s+");
		Matcher matcher = pattern.matcher(inputOne);
		
		System.out.println(matcher.replaceAll("----"));
	}
	
	// CASE_INSENSITIVE  reset
	public static void study002() {
		String inputOne	= "zENd.VN";
		String inputTwo = "Zend.VN";
			
		Pattern pattern = Pattern.compile("zend.vn", Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(inputOne);
		
		if (matcher.matches()) {
			System.out.println(inputOne +" Dữ liệu hợp lệ");
		} else {
			System.out.println(inputOne +" Dữ liệu không hợp lệ");
		}
		
		matcher.reset(inputTwo);
		if (matcher.matches()) {
			System.out.println(inputTwo +" Dữ liệu hợp lệ");
		} else {
			System.out.println(inputTwo +" Dữ liệu không hợp lệ");
		}
	}
	
	// Pattern + Matcher
	public static void study001() {
		String input = "aB1c_";
		
		// Case 01
		if(input.matches("[A-z_]+")){
			System.out.println("Dữ liệu hợp lệ");
		}else{
			System.out.println("Dữ liệu không hợp lệ");
		}
		
		// Case 02
		Pattern pattern 	= Pattern.compile("[A-z0-9_]+");
		Matcher matcher		= pattern.matcher(input);
		
		if(matcher.matches()){
			System.out.println("Dữ liệu hợp lệ");
		}else{
			System.out.println("Dữ liệu không hợp lệ");
		}
		
		// Case 03
		if(Pattern.matches("[A-z0-9_]+", "hnd!")){
			System.out.println("Dữ liệu hợp lệ");
		}else{
			System.out.println("Dữ liệu không hợp lệ");
		}
	}
}
