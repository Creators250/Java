package chap05.string;


public class StrReplace {
	
	public static void main(String[] args) {
		// replace
		study001();
		
		// replaceAll
//		study002();
//		study003();
	}
	// replaceAll
	// abcdAB69CD!@#$%^&*()0<>?_{}+21 ====>  69021
	public static void study003() {
		String str 	= "abcdAB69CD!@#$%^&*()0<>?_{}+21";
		System.out.println("Input: " + str); 
		
		str			= str.replaceAll("\\D", "");
		System.out.println("Output: " + str); 
	}
		
	// replaceAll
	// kho1a ho5c la65p tri2nh java	====>  khoa hoc lap trinh java
	public static void study002() {
		String str 	= "kho1a ho5c la65p tr232132i2nh java 123 13212";
		System.out.println("Input: " + str); 
		
		str			= str.replaceAll("\\d", "");

		System.out.println("Output: " + str); 
	}
		
	// replace
	// Java is vory vory oasy!	====> Java is very very easy!
	public static void study001() {
		String str 	= "Java is vory vory oasy!";
		System.out.println("Input: " + str); 
		
		str			= str.replace("o", "e");
		System.out.println("Output: " + str); 
	}
}
