package chap05.string;

import java.util.Scanner;

public class StrNumber {
	
	
	public static void main(String[] args) {
//		976 = Chín trăm bảy mươi sáu
//		206 = Hai trăm linh sáu
//		115 = Một trăm mười lăm
//		291 = Hai trăm chin mươi mốt
		boolean flagMatch 	= false;
		String input		= "";
		Scanner sc			= new Scanner(System.in);
		String result		= "";
		String str_000		= "";
		String str_00		= "";
		String str_0		= "";
		String[] dictionary	= {"không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"};
		
		do {
			System.out.println("Input: " ); 
			input	= sc.nextLine();
			
			if(input.matches("\\d{3}") == true) {
				// 01 - LẤY CHỮ SỐ HÀNG TRĂM, HÀNG CHỤC, HÀNG ĐƠN VỊ
				int digit_000	= Integer.parseInt(input.substring(0, 1));
				int digit_00	= Integer.parseInt(input.substring(1, 2));	// 123
				int digit_0		= Integer.parseInt(input.substring(2));	// 123

				System.out.println(digit_0);
				
				// 02 - HÀNG TRĂM
				str_000		= dictionary[digit_000] + " trăm ";
				
				// 03 - HÀNG CHỤC
				str_00		= dictionary[digit_00] + " mươi ";
				if(digit_00 == 0) str_00 = " linh ";
				if(digit_00 == 1) str_00 = " mười ";
				
				// 04 - HÀNG ĐƠN VỊ
				str_0		= dictionary[digit_0];
				if(digit_00 > 1 && digit_0 == 1) str_0 = " mốt ";
				if(digit_00 > 0 && digit_0 == 5) str_0 = " lăm ";
				
				if(digit_00 == 0 && digit_0 == 0){
					str_00 = "";
					str_0  = "";
				}
				
				if(digit_0 == 0){
					str_0  = "";
				}
				
				// KẾT QUẢ
				result		= str_000 + str_00 + str_0;
				
				
				System.out.println(result);
				flagMatch	= true;
			}else{
				System.out.println("Dữ liệu không hợp lệ");
			}
			
		} while (flagMatch == false);
		
		sc.close();
	}
}
