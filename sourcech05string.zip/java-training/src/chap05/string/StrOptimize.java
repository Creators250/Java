package chap05.string;

public class StrOptimize {
	
	public static void main(String[] args) {
		study002();
	}
	
	public static void study002() {
//		Không có khoảng trắng ở đầu và cuối chuỗi
//		Giữa các từ trong chuỗi chỉ tồn tại một khoảng trắng duy nhất
//		Ký tự đầu tiên trong chuỗi phải là ký tự in hoa, 
// 		Hết câu bằng dấu chấm
//		Các ký tự đầu tiên ở mỗi từ phải viết được viết hoa
		
		String	str		= "   " + "java   Is   veRY vERY   easy  ." + "  ";	// 3 + lenght + 2
		
		// Không có khoảng trắng ở đầu và cuối chuỗi
		str	= str.trim();
		
		// Giữa các từ trong chuỗi chỉ tồn tại một khoảng trắng duy nhất
		str	= str.replaceAll("\\s+\\.", ".");
		
		// Hết câu bằng dấu chấm
		if(str.charAt(str.length()-1) != '.') str	= str + ".";
		
		// Các ký tự đầu tiên ở mỗi từ phải viết được viết hoa
		// java is easy
		// java
		// is
		// easy
		// Java Is Easy 
		String[] strArr	= str.split("\\s+");
		StringBuilder strResult	= new StringBuilder();
//		for(String elem : strArr){
//			String strTmp	= elem.substring(0,1).toUpperCase() + elem.substring(1).toLowerCase();
//			strResult.append(strTmp).append(" ");
//		}
		
		for(int i = 0; i < strArr.length; i++){
			String strTmp	= strArr[i].substring(0,1).toUpperCase() + strArr[i].substring(1).toLowerCase();
			strResult.append(strTmp);
			if(i != strArr.length - 1) strResult.append(" ");
		}
		
		System.out.println(strResult);
	}
	
	public static void study001() {
//		Không có khoảng trắng ở đầu và cuối chuỗi
//		Giữa các từ trong chuỗi chỉ tồn tại một khoảng trắng duy nhất
//		Ký tự đầu tiên trong chuỗi phải là ký tự in hoa, 
//		Các ký tự còn lại ở dạng chữ thường
//		Hết câu bằng dấu chấm
		
		String	str		= "   " + "java   Is   easy  " + "  ";	// 3 + lenght + 2
		System.out.println(str.length());
		
		// Không có khoảng trắng ở đầu và cuối chuỗi
		str	= str.trim();
		
		// Giữa các từ trong chuỗi chỉ tồn tại một khoảng trắng duy nhất
		str	= str.replaceAll("\\s+", " ");
		str	= str.replaceAll("\\s+\\.", ".");
		
		//	Ký tự đầu tiên trong chuỗi phải là ký tự in hoa, 
		//	Các ký tự còn lại ở dạng chữ thường
		str	= str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
		
		// Hết câu bằng dấu chấm
		if(str.charAt(str.length()-1) != '.') str = str + ".";
		
		System.out.println(str);
	}
	
}