package chap05.string;

import java.util.Scanner;
import java.util.StringTokenizer;


public class StrSplit {
	
	public static void main(String[] args) {
		// Scanner
//		study001();
//		study002();
//		study003();
//		study004();
		
		// split
//		study005();
		
		// StringTokenizer 
		study006();
	}
	
	// StringTokenizer 
	// Không hỗ trợ RE
	public static void study006() {
		String str1	= "Java is very very easy";
		String str2	= "Java-is-very-very-easy";
		String str3	= "Java-is very very-easy";
		String str4	= "Java 12 is 233 very 32 very 156 easy";
		
		StringTokenizer strTokenizerObj	= new StringTokenizer(str4, "\\s+\\d+\\s+");
		while(strTokenizerObj.hasMoreTokens()){
			String token	= strTokenizerObj.nextToken();
			System.out.println(token);
		}
		
	}
		
	// split
	public static void study005() {
		String str1	= "Java is very very easy";
		String str2	= "Java-is-very-very-easy";
		String str3	= "Java-is very very-easy";
		String str4	= "Java 12 is 233 very 32 very 156 easy";
		
		String[] arrStr	= str4.split("\\s+\\d+\\s+");
		
		System.out.println(arrStr.length);
		for(String elm : arrStr){
			System.out.println(elm);
		}
	}
		
	// Scanner
	//  12 
	//     233 
	public static void study004() {
		String str	= "Java 12 is    233 very   32 very   156 easy";
 		Scanner sc	= new Scanner(str);
 		
 		sc.useDelimiter("\\s+\\d+\\s+");
 		while(sc.hasNext()){
 			String token	= sc.next();
 			System.out.println(token);
 		}
 		sc.close();
	}
	
	// Scanner
	public static void study003() {
		String str	= "Java-is very-very easy";
 		Scanner sc	= new Scanner(str);
 		
 		sc.useDelimiter("[- ]");
 		while(sc.hasNext()){
 			String token	= sc.next();
 			System.out.println(token);
 		}
 		sc.close();
	}
		
	// Scanner
	public static void study002() {
		String str	= "Java--is--very--very--easy";
 		Scanner sc	= new Scanner(str);
 		sc.useDelimiter("--");
 		while(sc.hasNext()){
 			String token	= sc.next();
 			System.out.println(token);
 		}
 		sc.close();
	}
	
	// Scanner
	public static void study001() {
		String str	= "Java is very very easy";
 		Scanner sc	= new Scanner(str);
 		
 		while(sc.hasNext()){
 			String token	= sc.next();
 			System.out.println(token);
 		}
 		
 		sc.close();
	}
}
