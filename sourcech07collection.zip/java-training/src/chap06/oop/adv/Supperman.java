package chap06.oop.adv;

public class Supperman extends Laptop implements People, Bird{

	@Override
	public void eat() {
		System.out.println("Supperman.eat()");
		
	}

	@Override
	public void sleep() {
		System.out.println("Supperman.sleep()");
		
	}
	
	public void abc() {
		System.out.println("Supperman.abc()");
		
	}

	@Override
	public void fly() {
		System.out.println("Supperman.fly()");
		
	}

	@Override
	public void mainboard(String param1) {
		// TODO Auto-generated method stub
		System.out.println("Supperman.mainboard()");
	}

	@Override
	public void chipset() {
		// TODO Auto-generated method stub
		
	}

}
