package chap06.oop.adv;

public interface Character {
	public void run();
	public void jump();
}
