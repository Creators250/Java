package chap06.oop.adv;

public class LaptopDell extends Laptop{
	public void keyboard(){
		System.out.println("LaptopDell.keyboard()");
	}

	@Override
	public void mainboard(String abc) {
		System.out.println("LaptopDell.mainboard()");
	}

	@Override
	public void chipset() {
		System.out.println("LaptopDell.chipset()");
	}
}
