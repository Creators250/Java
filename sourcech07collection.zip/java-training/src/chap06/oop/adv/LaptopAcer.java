package chap06.oop.adv;

public class LaptopAcer extends Laptop{

	@Override
	public void mainboard(String abc) {
		// TODO Auto-generated method stub
		System.out.println("LaptopAcer.mainboard()");
	}

	@Override
	public void chipset() {
		System.out.println("LaptopAcer.chipset()");
	}
}
