package chap06.oop.adv;

public class Main {
	
	public static void main(String[] args) {
		stuyd009();
	}
	
	// Inner Class - Nested Interface
	public static void stuyd009() {
		People.Student studentOBj	= new StudentZendVN();
		studentOBj.study();
	}
		
	// Inner Class - Static Nested Class
	public static void stuyd008() {
		Course.StaticClass staticClassObj	= new Course.StaticClass();
		staticClassObj.showInfo();
	}
		
	// Inner Class - Local Inner Class
	public static void stuyd007() {
		Course courseObj	= new Course("Java", 20);
		courseObj.showInfo();
	}
		
	// Inner Class - Anonymous Inner Class
	public static void stuyd006() {
		People peopleObj	= new People() {
			
			@Override
			public void sleep() {
				// TODO Auto-generated method stub
				System.out.println("Main.stuyd006().new People() {...}.sleep()");
			}
			
			@Override
			public void eat() {
				// TODO Auto-generated method stub
				System.out.println("Main.stuyd006().new People() {...}.eat()");
			}
		};
		
		peopleObj.eat();
		peopleObj.sleep();
	}
	
	// Inner Class - Member Inner Class
	public static void stuyd005() {
//		Course courseObj	= new Course("Java", 20);
//		Course.CourseOnline courseOnlineObj	= courseObj.new CourseOnline();
//		courseOnlineObj.showCourseOnlineInfo();
	}
	
	// Giảm thiểu sự phụ thuộc
	public static void stuyd004() {
		Playstation playObj	= new Playstation();
		Mario	marioObj	= new Mario();
		Fifa	fifaObj		= new Fifa();
		playObj.play(fifaObj);
	}
		
	// Object
	public static void stuyd003() {
		Course courseJava	= new Course("Java", 21);	// dsad123
		Course coursePHP	= new Course("PHP", 20);	// dds1123
		
		System.out.println(coursePHP);
		System.out.println(courseJava);
		
		if(courseJava.equals(coursePHP)){
			System.out.println("Bằng nhau");
		}else{
			System.out.println("Không Bằng nhau");
		}
	}
		
	// Interface
	public static void stuyd002() {
		
		Supperman peopleObj	= new Supperman();
		peopleObj.eat();
		peopleObj.sleep();
		peopleObj.abc();
		peopleObj.fly();
		peopleObj.chipset();
		peopleObj.mainboard("abc");
		peopleObj.defaultAbstract();
		People.staticAbstract();
	}

	// Abstract class
	public static void stuyd001() {
		
		Laptop laptopObj	= new LaptopDell();
		laptopObj.keyboard();
		laptopObj.mainboard("d");
		laptopObj.chipset();
		
		laptopObj			= new LaptopAcer();
		laptopObj.keyboard();
		laptopObj.mainboard("d");
		laptopObj.chipset();
	}
}
