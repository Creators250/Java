package chap06.oop.adv;

public interface Bird {
	public void fly();
}
