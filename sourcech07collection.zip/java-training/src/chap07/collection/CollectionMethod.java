package chap07.collection;

import java.util.*;
import javax.swing.plaf.ColorUIResource;

public class CollectionMethod {
	
	public static void main(String[] args) {
		ArrayList listObj		= new ArrayList();
		ArrayList listCourse	= new ArrayList();
		listCourse.add("Java");
		listCourse.add("Android");
		listCourse.add("IOS");
		
		listObj.add(1);	// 0
		listObj.add(5);	// 1
		listObj.add(3);	// 2
		listObj.add(7);	// 3
		listObj.add(4); // 4
		listObj.add(2);	// 5
//		System.out.println(Collections.min(listObj));
//		System.out.println(Collections.max(listObj));
		
		// SORT ASC
//		Collections.sort(listCourse);
		
		// SORT DESC
//		Collections.sort(listCourse);
//		Collections.reverse(listCourse);
		
		// FIND
//		int index = Collections.binarySearch(listCourse, "Android 2");
//		System.out.println(index);
		
		Collections.shuffle(listObj);
		Iterator itrCourse	= listObj.iterator();
		while(itrCourse.hasNext()){
			System.out.println(itrCourse.next());
		}
		
	}
}
