package chap07.collection;

import java.util.*;

public class CollectionComparable {
	
	public static void main(String[] args) {
		Course courseJava		= new Course("Java", 5);
		Course coursePHP		= new Course("PHP", 20);
		Course courseAndroid	= new Course("Android", 10);
		
		ArrayList arrCourse		= new ArrayList();
		
		arrCourse.add(coursePHP);
		arrCourse.add(courseAndroid);
		arrCourse.add(courseJava);
		arrCourse.add(new Course("Android adv", 15));
		
		Collections.sort(arrCourse);
		
		Iterator itr = arrCourse.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
	}
	
	
}
