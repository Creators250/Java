package chap07.collection;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class CollectionMap {
	
	public static void main(String[] args) {
		hashMap();
		System.out.println("================================");
		linkedHashMap();
		System.out.println("================================");
		treeMap();
		
	}
	public static void treeMap(){
		Map mapObj	= new TreeMap();
		
		mapObj.put("course_003", "IOS Programming");
		mapObj.put("course_001", "Java Programming");
		mapObj.put("course_005", "C# Programming");
		mapObj.put("course_002", "Android Programming");
		mapObj.put("course_004", "Swift Programming");
		
		Iterator itr	= mapObj.keySet().iterator();
		while(itr.hasNext()){
			Object key 		= itr.next();
			Object value	= mapObj.get(key);
			System.out.println(key + " : " + value);
		}
		
	}
	
	public static void linkedHashMap(){
		Map mapObj	= new LinkedHashMap();
		
		mapObj.put("course_003", "IOS Programming");
		mapObj.put("course_001", "Java Programming");
		mapObj.put("course_005", "C# Programming");
		mapObj.put("course_002", "Android Programming");
		mapObj.put("course_004", "Swift Programming");
		
		Iterator itr	= mapObj.keySet().iterator();
		while(itr.hasNext()){
			Object key 		= itr.next();
			Object value	= mapObj.get(key);
			System.out.println(key + " : " + value);
		}
		
	}
	
	public static void hashMap(){
		Map mapObj	= new HashMap();
		mapObj.put("course_003", "IOS Programming");
		mapObj.put("course_001", "Java Programming");
		mapObj.put("course_005", "C# Programming");
		mapObj.put("course_002", "Android Programming");
		mapObj.put("course_004", "Swift Programming");
		mapObj.put("course_004", "Swift Programming");
		
		System.out.println(mapObj.toString());
		Iterator itr	= mapObj.keySet().iterator();
		while(itr.hasNext()){
			Object key		= itr.next();
			Object value	= mapObj.get(key);
			System.out.println(key + ": " + value);
		}
	}
	
}
