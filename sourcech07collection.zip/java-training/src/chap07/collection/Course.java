package chap07.collection;

public class Course implements Comparable{
	
	private String name;
	private int time;
	
	public Course(String name, int time){
		this.setName(name);
		this.setTime(time);
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getTime() {
		return time;
	}
	
	public void setTime(int time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return this.getName() + " - " + this.getTime();
	}

	@Override
	public int compareTo(Object o) {
		Course courseObj	= (Course) o;
		if(this.getTime() > courseObj.getTime()) return -1;
		else if(this.getTime() < courseObj.getTime()) return 1;
		
		return 0;
	}
}
