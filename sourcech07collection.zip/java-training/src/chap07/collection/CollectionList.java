package chap07.collection;

import java.util.*;

public class CollectionList {
	
	public static void main(String[] args) {
		//arrayList();
		linkedlist();
	}
	
	public static void arrayList(){
		List listObj	= new ArrayList();
		Course courseObj= new Course("Java", 20);	
		
		// Adding object
		listObj.add("java");		// 0 String
		listObj.add(12);			// 1 Integer
		listObj.add(12.35);			// 2 Double
		listObj.add(true);			// 3 Boolean
		listObj.add(courseObj);		// 4 Course
		listObj.add(12);			// 5 Integer
		
		// Total Items
//		System.out.println(listObj.size());
		
		// GET ELEMENT
//		System.out.println(listObj.get(listObj.size() - 1));
		
		// SET
		listObj.set(0, "JAVA");
//		System.out.println(listObj.get(0));
		
		// Print all elements
//		for(int i = 0; i < listObj.size(); i++){
//			System.out.println(listObj.get(i));
//		}
		
//		for(Object elm : listObj){
//			System.out.println(elm);
//		}
		
		Iterator itr	= listObj.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		
		// REMOVE
		listObj.remove(courseObj);
		
		// REMOVE ALL
		listObj.clear();
		
		System.out.println("===============================");
		if(!listObj.isEmpty()){
			Iterator itr2	= listObj.iterator();
			while(itr2.hasNext() == true){
				System.out.println(itr2.next());
			}
		}else{
			System.out.println("List is empty!");
		}
	}
	
	public static void linkedlist(){
		List listObj	= new LinkedList();
		Course courseObj= new Course("Java", 20);	
		
		// Adding object
		listObj.add("java");		// 0 String
		listObj.add(12);			// 1 Integer
		listObj.add(12.35);			// 2 Double
		listObj.add(true);			// 3 Boolean
		listObj.add(courseObj);		// 4 Course
		listObj.add(12);			// 5 Integer
		
		// Total Items
//		System.out.println(listObj.size());
		
		// GET ELEMENT
//		System.out.println(listObj.get(listObj.size() - 1));
		
		// SET
		listObj.set(0, "JAVA");
//		System.out.println(listObj.get(0));
		
		// REMOVE
		listObj.remove(courseObj);
		
		// REMOVE ALL
//		listObj.clear();
		
		System.out.println("===============================");
		if(!listObj.isEmpty()){
			Iterator itr2	= listObj.iterator();
			while(itr2.hasNext() == true){
				System.out.println(itr2.next());
			}
		}else{
			System.out.println("List is empty!");
		}
	}
	
}
