package chap07.collection;

import java.util.*;

public class CollectionSet {
	
	public static void main(String[] args) {
		hashSet();
		System.out.println("=======================");
		linkedHashSet();
		System.out.println("=======================");
		treeSet();
	}
	
	public static void treeSet(){
		Set setObj	= new TreeSet();
		
		setObj.add(21);
		setObj.add(22);
		setObj.add(7);
		setObj.add(3);
		setObj.add(4);
		setObj.add(9);
		setObj.add(1);
		setObj.add(4);
		setObj.add(13);
		
		Iterator itr	= setObj.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
	}
	
	public static void linkedHashSet(){
		Set setObj	= new LinkedHashSet();
		
		setObj.add(21);
		setObj.add(22);
		setObj.add(7);
		setObj.add(3);
		setObj.add(4);
		setObj.add(9);
		setObj.add(1);
		setObj.add(4);
		setObj.add(13);
		
		Iterator itr	= setObj.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
	}
	
	public static void hashSet(){
		Set setObj	= new HashSet();
		
		setObj.add(21);
		setObj.add(22);
		setObj.add(7);
		setObj.add(3);
		setObj.add(4);
		setObj.add(9);
		setObj.add(1);
		setObj.add(4);
		setObj.add(13);
		// 21 22 7 3 4 9 1 4 13
		
		Iterator itr	= setObj.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
	}
	
}
