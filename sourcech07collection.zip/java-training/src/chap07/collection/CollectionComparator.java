package chap07.collection;

import java.util.*;

public class CollectionComparator {
	
	public static void main(String[] args) {
		ArrayList arrCourse		= new ArrayList<Course>();
		
		arrCourse.add(new Course("Java", 5));
		arrCourse.add(new Course("PHP", 20));
		arrCourse.add(new Course("Android", 10));
		
//		Collections.sort(arrCourse, new NameComparator());
		Collections.sort(arrCourse, new Comparator() {

			@Override
			public int compare(Object o1, Object o2) {
				Course courseObj1	= (Course) o1;
				Course courseObj2	= (Course) o2;
				
				if(courseObj1.getTime() > courseObj2.getTime()) return 1;
				else if(courseObj1.getTime() < courseObj2.getTime()) return -1;
				
				return 0;
			}
			
		});
		
		Iterator itr = arrCourse.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
	}
	

}
