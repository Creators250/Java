package chap07.collection;

import java.util.Comparator;

public class NameComparator implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		Course courseObj1	= (Course) o1;
		Course courseObj2	= (Course) o2;
		
		return courseObj2.getName().compareTo(courseObj1.getName());
	}

}
