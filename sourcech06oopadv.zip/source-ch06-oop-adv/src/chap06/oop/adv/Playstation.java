package chap06.oop.adv;

public class Playstation {
	
	public void play(Character obj){
		obj.run();
		obj.jump();
	}
}
