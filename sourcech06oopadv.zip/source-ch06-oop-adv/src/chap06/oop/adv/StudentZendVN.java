package chap06.oop.adv;

public class StudentZendVN implements People.Student {

	@Override
	public void study() {
		System.out.println("StudentZendVN.study()");
		
	}

}
