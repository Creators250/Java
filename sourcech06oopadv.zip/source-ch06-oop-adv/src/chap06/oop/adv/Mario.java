package chap06.oop.adv;

public class Mario implements Character{

	public void jump() {
		System.out.println("Mario.jump()");
	}

	public void run() {
		System.out.println("Mario.run()");
	}

}
