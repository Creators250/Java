package chap06.oop.adv;

public class Course{
	private String name;
	private int time;
	static int chapter	= 12;
	
	static class StaticClass{
		public void showInfo(){
			System.out.println("Name: " + chapter);
		}
	}
	
	public Course(String name, int time){
		this.setName(name);
		this.setTime(time);
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getTime() {
		return time;
	}
	
	public void setTime(int time) {
		this.time = time;
	}
	
	@Override
	public String toString() {
		String result	= "Course Info: \n - Name \t:" + this.getName() + "\n - Time  \t:" + this.getTime();
		
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		Course courseObj	= (Course) obj;
		if(this.getTime() == courseObj.getTime() + 1) return true;
		return false;
	}
	
	public void showInfo(){
		System.out.println("Name: " + getName());
		System.out.println("Time: " + time);
		int score	= 50;
		
		class CourseOnline{
			private double cost	= 20;

			public double getCost() {
				return cost;
			}

			public void setCost(double cost) {
				this.cost = cost;
			}
			
			public void showCourseOnlineInfo(){
				System.out.println("Name: " + name);
				System.out.println("Time: " + getTime());
				System.out.println("Price: " + this.getCost());
				System.out.println("Score: " + score);
			}
		}
		
		CourseOnline courseOnlineObj	= new CourseOnline();
		courseOnlineObj.showCourseOnlineInfo();
		
	}
	
}
