package chap06.oop.adv;

public interface People {
	public void eat();
	public void sleep();

	interface Student{
		public void study();
	}
	public default void defaultAbstract(){
		System.out.println("People.abcAbstract()");
	}
	public static void staticAbstract(){
		System.out.println("People.staticAbstract()");
	}
}
