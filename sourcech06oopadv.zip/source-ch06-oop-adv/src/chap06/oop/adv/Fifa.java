package chap06.oop.adv;

public class Fifa implements Character{
	
	public void jump() {
		System.out.println("Fifa.jump()");
	}

	public void run() {
		System.out.println("Fifa.run()");
	}
}
