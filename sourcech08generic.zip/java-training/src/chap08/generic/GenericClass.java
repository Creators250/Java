package chap08.generic;

public class GenericClass {
	
	public static void main(String[] args) {
		CourseAdv<Integer, Double> courseObj	= new CourseAdv();
		courseObj.setTime(12);
		courseObj.setChapter(12.2);
	}
	
	
}
