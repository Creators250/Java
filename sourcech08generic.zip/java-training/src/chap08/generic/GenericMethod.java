package chap08.generic;

public class GenericMethod {
	
	public static void main(String[] args) {
		Integer[] arrInt 	= { 10, 20, 30, 40, 50 };  // int
		String[] arrStr		= { "Java", "Android", "PHP"};
		
//		printArrayInt(arrInt);
//		printArrayStr(arrStr);
		printArray(arrInt);
		printArray(arrStr);
		
		Course courseObj	= new Course("java", 20);
		CourseOnline courseOnlineObj	= new CourseOnline("android", 50);
		print(courseObj);
		print(courseOnlineObj);
	}
	
	public static <M extends Course> void print(M obj) {  
        System.out.println("GenericMethod.print()"); 
    }  
	
	public static <M extends Object> void printArray(M[] arr) {  
        for ( M elm : arr){          
            System.out.println(elm);  
        }  
    }  
	
	public static void printArrayInt(Integer[] arrInt) {  
        for ( Integer elm : arrInt){          
            System.out.println(elm);  
        }  
    }  
	
	public static void printArrayStr(String[] arrStr) {  
        for ( String elm : arrStr){          
            System.out.println(elm);  
        }  
    }  
}
