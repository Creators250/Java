package chap08.generic;

public class CourseOnline extends Course{

	public CourseOnline(String name, int time) {
		super(name, time);
	}
}
