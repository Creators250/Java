package chap08.generic;

import java.util.*;

public class GenericCollection {
	
	public static void main(String[] args) {
		collectionList();
//		collectionSet();
//		collectionMap();
	}
	
	public static void collectionMap() {
		Map<Double, String> mapObj	= new HashMap<Double, String>();
		mapObj.put(4.8, "IOS Programming");
		mapObj.put(1.9, "Java Programming");
		mapObj.put(5.8, "C# Programming");
		mapObj.put(2.1, "Android Programming");
		
		Iterator<Double> itr	= mapObj.keySet().iterator();
		while(itr.hasNext()){
			Double key 	= itr.next();
			String value	= mapObj.get(key);
			System.out.println(key + " : " + value);
		}
	}
	
	public static void collectionSet() {
		Set<String> setObj	= new HashSet<String>();
//		setObj.add(12);
		setObj.add("Java");
		setObj.add("Android");
		
		Iterator<String> itr	= setObj.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
	}
	
	public static void collectionList() {
		List<Object> listObj	= new ArrayList<Object>();
		listObj.add(1);
		listObj.add(3);
		listObj.add(2);
		listObj.add(new Course("java", 30));
		listObj.add(5.12);
		listObj.add(true);
		
		Iterator<Object> itr	= listObj.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		
		List<Course> listCourse	= new ArrayList<Course>();
		listCourse.add(new Course("java", 30));
		
		Iterator<Course> itr2	= listCourse.iterator();
		while(itr2.hasNext()){
			System.out.println(itr2.next());
		}
	}
}
